<template>
    <div>
        <br>
        <h1>Support Page</h1>
        <br>
        <div></div>
    </div>
</template>

<script>
    export default {
        name: "Help"
    }
</script>

<style scoped>

</style>