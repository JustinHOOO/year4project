<template>
    <div class="footer-inner">
        @copyright HUJINKE 2024
    </div>
</template>

<script>
    export default {
        name: "Footer"
    }
</script>

<style scoped>
    .footer-inner {
        padding: 20px;
        background-color: white;
    }
</style>