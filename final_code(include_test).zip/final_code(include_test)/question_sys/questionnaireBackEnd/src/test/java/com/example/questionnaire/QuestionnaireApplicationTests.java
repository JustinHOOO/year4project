package com.example.questionnaire;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuestionnaireApplicationTests {

    @Test
    void contextLoads() {
    }

}
